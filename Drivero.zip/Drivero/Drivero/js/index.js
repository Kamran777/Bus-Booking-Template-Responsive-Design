$(".navbar-toggler").click(function() {
  	$(".header-content").toggle();
});